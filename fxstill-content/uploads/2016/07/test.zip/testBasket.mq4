//+------------------------------------------------------------------+
//|                                                    PCandlesF.mq4 |
//|                        Copyright 2014, MetaQuotes Software Corp. |
//|                                              http://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2014, MetaQuotes Software Corp."
#property link      "http://www.mql5.com"
#property version   "1.00"
#property strict

#property indicator_separate_window

#property indicator_buffers 1

input int     iBarsTotal  = 300;   //Max.Candle count          
input ENUM_APPLIED_PRICE ap = PRICE_CLOSE;    //Applied price

string pair[] = {"EURUSD","GBPUSD","AUDUSD","NZDUSD","USDCAD","USDCHF","USDJPY"};
bool bDirect[] = {false,false,false,false,true,true,true};
int iCount = 7;


double GetValue(int shift) {
      double res = 1.0, t;
      for (int i = 0; i < iCount; i++) {
         switch (ap)
         {
            case PRICE_OPEN:
               t = iOpen(pair[i],0,shift);
               break;
            case PRICE_HIGH:
               t = iHigh(pair[i], 0, shift);
               break;
            case PRICE_LOW:
               t = iLow(pair[i], 0, shift);
               break;
            case PRICE_CLOSE:
               t = iClose(pair[i], 0, shift);
               break;
            case PRICE_MEDIAN:
               t = (iHigh(pair[i], 0, shift) + iLow(pair[i], 0, shift)) / 2;
               break;
            case PRICE_TYPICAL:
               t = (iHigh(pair[i], 0, shift) + iLow(pair[i], 0, shift) + iClose(pair[i], 0, shift)) / 3;
               break;
            case PRICE_WEIGHTED:
               t = (iHigh(pair[i], 0, shift) + iLow(pair[i], 0, shift) + iClose(pair[i], 0, shift) * 2) / 4;
               break;
            default:
               t = iClose(pair[i], 0, shift);
               break;
         }//end switch (ap)    
         if (t == 0)       return 0;  
         if (!bDirect[i] ) t = 1/t; 
         res *= t;
      }//end for (int i = 0; i < iCount; i++)
      return (NormalizeDouble(MathPow (res, 1/(double)iCount), _Digits) );
   }
   

double upp[];

int OnInit()
{
   IndicatorShortName("testBasket");
   IndicatorDigits(_Digits); 
   SetIndexStyle(0,DRAW_LINE, STYLE_SOLID, 2 ,clrGreen );
   SetIndexBuffer(0,upp);
   SetIndexLabel(0,"testBasket" );   
       
   return(INIT_SUCCEEDED);
}

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   if (prev_calculated == 0) {
   
      int total;
      if (iBarsTotal == 0) total = rates_total;
      else total = MathMin(iBarsTotal,rates_total);
      for (int i = 0; i < total; i++) upp[i] = GetValue(i);
   }//end if (prev_calculated == 0)
   else {
      upp[0] = GetValue(0);
   }
   return(rates_total);
}
