//+------------------------------------------------------------------+
//|                                                BetterVolumeA.mq4 |
//|                                          Copyright 2014, Andrei. |
//|                                              http://FxStill.com  |
//+------------------------------------------------------------------+
#property copyright "FxStill.com"
#property link      "http://FxStill.com"
#property version   "1.0"
#property strict
#property indicator_chart_window


#define NAME  "BetterVolumeA"
#property indicator_separate_window
#property indicator_buffers 7

#define	 BUYCOLOR	(color)clrRoyalBlue //���� �� �������
#define	 SELLCOLOR	(color)clrRed       //���� �� �������
#define   MACOLOR    (color)clrLime      //���� "���������� �������"
#define   BARSTOTALCOUNT (int)300        //������������ ���-�� ������ ��� �������� �����������

extern int   iBarsTotal = BARSTOTALCOUNT; //���-�� ������ ��� �������
input int    LookBack   = 20;             //��� ���������� �����������
input color  cBuy       = BUYCOLOR;       //"����������� �������"
input color  cSell      = SELLCOLOR;      //"�����������" ������
input color  cSimple    = clrDimGray;     //����������� �����
input color  cLow       = clrSilver;      //������ �����
input color  cChurn     = clrForestGreen; //�������� �������
input color  cCChurn    = clrMagenta;     //������� ����� � �����
input int    iW         = 3;              //������� �����
input bool   bShowMA    = false;           //�������� �������
input color  cMA        = MACOLOR;        //���� �������
input int    MAPeriod   = 100;            //������ �������

ENUM_LINE_STYLE eSl = STYLE_SOLID;

double red[],blue[],yellow[],green[],white[],magenta[],v4[];   

int OnInit()
{
   IndicatorShortName(NAME);
   IndicatorDigits(2);

   SetIndexBuffer(0,red);
   SetIndexStyle(0,DRAW_HISTOGRAM,eSl, iW,cBuy);
   SetIndexLabel(0,"ClimaxHigh");

   SetIndexBuffer(1,blue);
   SetIndexStyle(1,DRAW_HISTOGRAM, eSl, iW, cSimple);
   SetIndexLabel(1,"Neutral");   
   
   SetIndexBuffer(2,yellow);
   SetIndexStyle(2,DRAW_HISTOGRAM, eSl, iW, cLow);
   SetIndexLabel(2,"Low");   
      
   SetIndexBuffer(3,green);
   SetIndexStyle(3,DRAW_HISTOGRAM, eSl, iW, cChurn);
   SetIndexLabel(3,"HighChurn");      
      
   SetIndexBuffer(4,white);
   SetIndexStyle(4,DRAW_HISTOGRAM, eSl, iW, cSell);
   SetIndexLabel(4,"ClimaxLow");      
      
   SetIndexBuffer(5,magenta);
   SetIndexStyle(5,DRAW_HISTOGRAM, eSl, iW, cCChurn);
   SetIndexLabel(5,"ClimaxChurn");      
   
   if (bShowMA == true) {
      SetIndexBuffer(6,v4);
      SetIndexStyle(6,DRAW_LINE, eSl, iW, cMA);
      SetIndexLabel(6,"Average(" + IntegerToString(MAPeriod) + ")");   
   } else {
      SetIndexStyle(6,DRAW_NONE);
      SetIndexLabel(6,"");   
   }   
	
   PrintFormat("%s report: %s",NAME, _Symbol);            
   return(INIT_SUCCEEDED);
}

/*************************************/

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
{
   long VolLowest;
   double Range, Value2, Value3, HiValue2, HiValue3;
   
   if (prev_calculated == 0) {
      if (iBarsTotal == 0) iBarsTotal = rates_total;
      else iBarsTotal = MathMin(iBarsTotal,rates_total);
      for (int i = 1; i < iBarsTotal - LookBack; i++) {
         CalcParam(i, VolLowest, Range, Value2, Value3, HiValue2, HiValue3);
         ProcessParam(i, VolLowest, Value2, Value3, HiValue2, HiValue3);

      }// end for (int i = 1; i < iBarsTotal - LookBack; i++)         
   }//end if (prev_calculated == 0)
   else {
      red[0] = blue[0] = yellow[0] = green[0] = white[0] = magenta[0] = 0.0;
      CalcParam(0, VolLowest, Range, Value2, Value3, HiValue2, HiValue3);
      ProcessParam(0, VolLowest, Value2, Value3, HiValue2, HiValue3);
   }
   return(rates_total);
}

void ProcessParam(int i, long VolLowest, double Value2,double Value3,double HiValue2,double HiValue3) {
         if (bShowMA == true && i <= iBarsTotal - MAPeriod) {
            long m = 0;
            for (int j = 0; j < MAPeriod; j++)  m += Volume[i + j];
            v4[i] = NormalizeDouble(m/MAPeriod,2);
         }   
         if (Volume[i] == VolLowest) {
            yellow[i] = (double)Volume[i];
            return;
         }           
         if (Value2 == HiValue2  && Close[i] > (High[i] + Low[i]) / 2 )  {     //����������� �������
            red[i] = NormalizeDouble(Volume[i],2); 
            return;
         }
         if (Value2 == HiValue2  && Close[i] <= (High[i] + Low[i]) / 2 ) {     //����������� ������
            white[i] = NormalizeDouble(Volume[i],2);
            return;
         }          
         if ( Value2 == HiValue2 && Value3 == HiValue3 )                 {     //������ ���������
            magenta[i] = NormalizeDouble(Volume[i],0);
            return;
         }           
         if ( Value3 == HiValue3 )                                       {     //�������� �������
            green[i] = NormalizeDouble(Volume[i],0);                
            return;
         }             
         blue[i] = (double) Volume[i];
}
void CalcParam(int i, long& VolLowest, double& Range,double& Value2,double& Value3,double& HiValue2,double& HiValue3) {
         VolLowest  = Volume[iLowest(NULL,0,MODE_VOLUME,LookBack,i)];     
         Range      = High[i]-Low[i];  
         Value2     = Volume[i]*Range;
         Value3     = 0;       
         if (Range != 0) Value3 = Volume[i]/Range;
         HiValue2   = 0;
         HiValue3   = 0;
         double r, tv2, tv3;
         for (int n = i; n < i + LookBack; n++) {
            r = High[n] - Low[n];
            tv2 = Volume[n] * r; 
            tv3 = 0;
            if (tv2 >= HiValue2) HiValue2 = tv2;
            if (tv2 != 0.0) tv3 = Volume[n] / r;
            if (tv3 > HiValue3) HiValue3 = tv3;   
         }//end for (int n = i;n < i + LookBack; n++)
}

void OnDeinit(const int reason) {
   for (int i = ObjectsTotal() - 1; i >= 0; i--)
      if (StringFind(ObjectName(i), NAME, 0) == 0) ObjectDelete(ObjectName(i) );
   string text;
   switch(reason)
     {
      case REASON_PROGRAM:
         text="Indicator terminated its operation by calling the ExpertRemove() function";break;
      case REASON_INITFAILED:
         text="This value means that OnInit() handler "+__FILE__+" has returned a nonzero value";break;
      case REASON_CLOSE:
         text = "Terminal has been closed"; break;
      case REASON_ACCOUNT:
         text="Account was changed";break;
      case REASON_CHARTCHANGE:
         text="Symbol or timeframe was changed";break;
      case REASON_CHARTCLOSE:
         text="Chart was closed";break;
      case REASON_PARAMETERS:
         text="Input-parameter was changed";break;
      case REASON_RECOMPILE:
         text="Program "+__FILE__+" was recompiled";break;
      case REASON_REMOVE:
         text="Program "+__FILE__+" was removed from chart";break;
      case REASON_TEMPLATE:
         text="New template was applied to chart";break;
      default:text="Another reason";
     }   
     PrintFormat("%s",text);

}