//+------------------------------------------------------------------+
//|                                            BetterVolumeA MT5.mq4 |
//|                                          Copyright 2014, Andrei  |
//|                                              http://FxStill.com  |
//+------------------------------------------------------------------+
#property copyright "FxStill.com"
#property link      "http://FxStill.com"
#property description "BetterVolumeA MT5"

#define NAME  "BetterVolumeA"

#property indicator_separate_window
#property indicator_buffers 7
#property indicator_plots 7


#define	 BUYCOLOR	(color)clrRoyalBlue //���� �� �������
#define	 SELLCOLOR	(color)clrRed       //���� �� �������
#define   MACOLOR    (color)clrLime      //���� "���������� �������"
#define   BARSTOTALCOUNT (int)3000        //������������ ���-�� ������ ��� �������� �����������

extern int   iBarsTotal = BARSTOTALCOUNT; //���-�� ������ ��� �������
input int    LookBack   = 20;             //��� ���������� �����������
input color  cBuy       = BUYCOLOR;       //"����������� �������"
input color  cSell      = SELLCOLOR;      //"�����������" ������
input color  cSimple    = clrDimGray;     //����������� �����
input color  cLow       = clrSilver;      //������ �����
input color  cChurn     = clrForestGreen; //�������� �������
input color  cCChurn    = clrMagenta;     //������� ����� � �����
input int    iW         = 3;              //������� �����
input bool   bShowMA=false;           //�������� �������
input color  cMA        = MACOLOR;        //���� �������
input int    MAPeriod   = 100;            //������ �������

ENUM_LINE_STYLE eSl=STYLE_SOLID;
double red[],blue[],yellow[],green[],white[],magenta[],v4[];
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   IndicatorSetInteger(INDICATOR_DIGITS,_Digits);
   IndicatorSetString(INDICATOR_SHORTNAME,NAME);
   SetIndexBuffer(0,red,INDICATOR_DATA);
   ArraySetAsSeries(red,true);
   PlotIndexSetInteger(0,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(0,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(0,PLOT_LINE_COLOR,cBuy);
   PlotIndexSetInteger(0,PLOT_LINE_STYLE,eSl);
   PlotIndexSetString(0,PLOT_LABEL,"ClimaxHigh");

   SetIndexBuffer(1,blue,INDICATOR_DATA);
   ArraySetAsSeries(blue,true);
   PlotIndexSetInteger(1,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(1,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(1,PLOT_LINE_COLOR,cSimple);
   PlotIndexSetInteger(1,PLOT_LINE_STYLE,eSl);
   PlotIndexSetString(1,PLOT_LABEL,"Neutral");

   SetIndexBuffer(2,yellow,INDICATOR_DATA);
   ArraySetAsSeries(yellow,true);
   PlotIndexSetInteger(2,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(2,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(2,PLOT_LINE_COLOR,cLow);
   PlotIndexSetInteger(2,PLOT_LINE_STYLE,STYLE_SOLID);
   PlotIndexSetString(2,PLOT_LABEL,"Low");

   SetIndexBuffer(3,green,INDICATOR_DATA);
   ArraySetAsSeries(green,true);
   PlotIndexSetInteger(3,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(3,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(3,PLOT_LINE_COLOR,cChurn);
   PlotIndexSetInteger(3,PLOT_LINE_STYLE,eSl);
   PlotIndexSetString(3,PLOT_LABEL,"HighChurn");

   SetIndexBuffer(4,white,INDICATOR_DATA);
   ArraySetAsSeries(white,true);
   PlotIndexSetInteger(4,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(4,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(4,PLOT_LINE_COLOR,cSell);
   PlotIndexSetInteger(4,PLOT_LINE_STYLE,eSl);
   PlotIndexSetString(4,PLOT_LABEL,"ClimaxLow");

   SetIndexBuffer(5,magenta,INDICATOR_DATA);
   ArraySetAsSeries(magenta,true);
   PlotIndexSetInteger(5,PLOT_DRAW_TYPE,DRAW_HISTOGRAM);
   PlotIndexSetInteger(5,PLOT_LINE_WIDTH,iW);
   PlotIndexSetInteger(5,PLOT_LINE_COLOR,cCChurn);
   PlotIndexSetInteger(5,PLOT_LINE_STYLE,eSl);
   PlotIndexSetString(5,PLOT_LABEL,"ClimaxChurn");

   if(bShowMA==true)
     {
      SetIndexBuffer(6,v4,INDICATOR_DATA);
      ArraySetAsSeries(v4,true);
      PlotIndexSetInteger(6,PLOT_DRAW_TYPE,DRAW_LINE);
      PlotIndexSetInteger(6,PLOT_LINE_WIDTH,iW);
      PlotIndexSetInteger(6,PLOT_LINE_COLOR,cMA);
      PlotIndexSetInteger(6,PLOT_LINE_STYLE,eSl);
      PlotIndexSetString(6,PLOT_LABEL,"Average("+IntegerToString(MAPeriod)+")");
        } else {
      PlotIndexSetInteger(6,PLOT_DRAW_TYPE,DRAW_NONE);
      PlotIndexSetString(6,PLOT_LABEL,"");
     }

   PrintFormat("%s report: %s",NAME,_Symbol);
   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
/*************************************/

int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   long VolLowest;
   double Range,Value2,Value3,HiValue2,HiValue3;

   if(prev_calculated==0)
     {
      if(iBarsTotal==0) iBarsTotal=rates_total;
      else iBarsTotal=MathMin(iBarsTotal,rates_total);
      for(int i=0;i<iBarsTotal && !IsStopped();i++)
        {
         red[i]=blue[i]=yellow[i]=green[i]=white[i]=magenta[i]=0.0;
         CalcParam(i,VolLowest,Range,Value2,Value3,HiValue2,HiValue3);
         ProcessParam(i,VolLowest,Value2,Value3,HiValue2,HiValue3);
        }//  for(int i=0;i<rates_total && !IsStopped();i++)

     }//end if (prev_calculated == 0)
   else
     {
      red[0]=blue[0]=yellow[0]=green[0]=white[0]=magenta[0]=0.0;
      CalcParam(0,VolLowest,Range,Value2,Value3,HiValue2,HiValue3);
      ProcessParam(0,VolLowest,Value2,Value3,HiValue2,HiValue3);
     }
   return(rates_total);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void ProcessParam(int i,long VolLowest,double Value2,double Value3,double HiValue2,double HiValue3)
  {
   if(bShowMA==true && i<=iBarsTotal-MAPeriod)
     {
      long m=0;
      for(int j=0; j<MAPeriod; j++) m+=Volume(i+j);
      v4[i]=NormalizeDouble(m/MAPeriod,2);
     }
   if(Volume(i)==VolLowest)
     {
      yellow[i]=(double)Volume(i);
      return;
     }
   if(Value2==HiValue2 && Close(i)>(High(i)+Low(i))/2)
     {     //����������� �������
      red[i]=NormalizeDouble(Volume(i),2);
      return;
     }
   if(Value2==HiValue2 && Close(i)<=(High(i)+Low(i))/2)
     {     //����������� ������
      white[i]=NormalizeDouble(Volume(i),2);
      return;
     }
   if(Value2==HiValue2 && Value3==HiValue3)
     {     //������ ���������
      magenta[i]=NormalizeDouble(Volume(i),0);
      return;
     }
   if(Value3==HiValue3)
     {     //�������� �������
      green[i]=NormalizeDouble(Volume(i),0);
      return;
     }
   blue[i]=(double) Volume(i);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void CalcParam(int i,long &VolLowest,double &Range,double &Value2,double &Value3,double &HiValue2,double &HiValue3)
  {
   VolLowest  = Volume(iLowest(NULL,0,LookBack,i));
   Range      = High(i)-Low(i);
   Value2     = Volume(i)*Range;
   Value3     = 0;
   if(Range!=0) Value3=Volume(i)/Range;
   HiValue2   = 0;
   HiValue3   = 0;
   double r,tv2,tv3;
   for(int n=i; n<i+LookBack; n++)
     {
      r=High(n)-Low(n);
      tv2 = Volume(n) * r;
      tv3 = 0;
      if(tv2 >= HiValue2) HiValue2 = tv2;
      if(tv2 != 0.0) tv3 = Volume(n) / r;
      if(tv3>HiValue3) HiValue3=tv3;
     }//end for (int n = i;n < i + LookBack; n++)
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
  {
   for(int i=ObjectsTotal(0)-1; i>=0; i--)
      if(StringFind(ObjectName(0,i),NAME,0)==0) ObjectDelete(0,ObjectName(0,i));
   string text;
   switch(reason)
     {
      case REASON_PROGRAM:
         text="Indicator terminated its operation by calling the ExpertRemove() function";break;
      case REASON_INITFAILED:
         text="This value means that OnInit() handler "+__FILE__+" has returned a nonzero value";break;
      case REASON_CLOSE:
         text="Terminal has been closed"; break;
      case REASON_ACCOUNT:
         text="Account was changed";break;
      case REASON_CHARTCHANGE:
         text="Symbol or timeframe was changed";break;
      case REASON_CHARTCLOSE:
         text="Chart was closed";break;
      case REASON_PARAMETERS:
         text="Input-parameter was changed";break;
      case REASON_RECOMPILE:
         text="Program "+__FILE__+" was recompiled";break;
      case REASON_REMOVE:
         text="Program "+__FILE__+" was removed from chart";break;
      case REASON_TEMPLATE:
         text="New template was applied to chart";break;
      default:text="Another reason";
     }
   PrintFormat("%s",text);

  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
long Volume(int i)
  {
   long res[1];
   if(CopyTickVolume(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double Close(int i)
  {
   double res[1];
   if(CopyClose(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double High(int i)
  {
   double res[1];
   if(CopyHigh(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double Open(int i)
  {
   double res[1];
   if(CopyOpen(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double Low(int i)
  {
   double res[1];
   if(CopyLow(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);

  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
datetime Time(int i)
  {
   datetime res[];
   ArraySetAsSeries(res,true);
   if(CopyTime(_Symbol,_Period,i,1,res) != -1) return (res[0]);
   return (0);

  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int iLowest(string _symbol,ENUM_TIMEFRAMES _t,int _count=WHOLE_ARRAY,int _start=0)
  {
   if(_start<0) return(-1);
   if(_count<=0) _count=Bars(_symbol,_t);
   long _Volume[];
   ArraySetAsSeries(_Volume,true);
   CopyTickVolume(_symbol,_t,_start,_count,_Volume);
   return(ArrayMinimum(_Volume,0,_count)+_start);
   return(0);
  }
//+------------------------------------------------------------------+
