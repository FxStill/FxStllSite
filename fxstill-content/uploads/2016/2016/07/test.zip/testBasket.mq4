//+------------------------------------------------------------------+
//|                                                   testBasket.mq4 |
//|                                          Copyright 2014, Andrei  |
//|                                              http://FxStill.com  |
//+------------------------------------------------------------------+
#property copyright "FxStill.com"
#property link      "http://FxStill.com"
#property version   "1.00"
#property strict

#property indicator_separate_window

#property indicator_buffers 1

input int     iBarsTotal=300;

string pair[]={"EURUSD","GBPUSD","AUDUSD","NZDUSD","USDCAD","USDCHF","USDJPY"};
bool bDirect[]={false,false,false,false,true,true,true};
int iCount=7;
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
double GetValue(int shift) 
  {
   double res=1.0,t;
   for(int i=0; i<iCount; i++) 
     {
      t=iClose(pair[i],0,shift);
      if(!bDirect[i]) t=1/t;
      res*=t;
     }//end for (int i = 0; i < iCount; i++)
   return (NormalizeDouble(MathPow (res, 1/(double)iCount), _Digits) );
  }

double upp[];
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnInit()
  {
   IndicatorShortName("testBasket");
   IndicatorDigits(_Digits);
   SetIndexStyle(0,DRAW_LINE,STYLE_SOLID,2,clrGreen);
   SetIndexBuffer(0,upp);
   SetIndexLabel(0,"testBasket");

   return(INIT_SUCCEEDED);
  }
//+------------------------------------------------------------------+
//|                                                                  |
//+------------------------------------------------------------------+
int OnCalculate(const int rates_total,
                const int prev_calculated,
                const datetime &time[],
                const double &open[],
                const double &high[],
                const double &low[],
                const double &close[],
                const long &tick_volume[],
                const long &volume[],
                const int &spread[])
  {
   if(prev_calculated==0) 
     {

      int total;
      if(iBarsTotal==0) total=rates_total;
      else total= MathMin(iBarsTotal,rates_total);
      for(int i = 0; i<total; i++) upp[i] = GetValue(i);
     }//end if (prev_calculated == 0)
   else 
     {
      upp[0]=GetValue(0);
     }
   return(rates_total);
  }
//+------------------------------------------------------------------+
