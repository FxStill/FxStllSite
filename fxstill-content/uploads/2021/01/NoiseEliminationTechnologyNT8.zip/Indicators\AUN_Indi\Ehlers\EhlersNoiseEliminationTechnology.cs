#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators.AUN_Indi.Ehlers
{
	public class EhlersNoiseEliminationTechnology : Indicator
	{
		private double Denom, Num;
		private double[] a1, a2;
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Noise Elimination Technology: John Ehlers, Stocks & Commodities. Dec.2020 pg. 16-18";
				Name										= "EhlersNoiseEliminationTechnology";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= false;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= false;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Period					= 14;
				Multi					= 1;
				AddPlot(Brushes.Aqua, "Net_Ehlers");
				AddLine(Brushes.DarkCyan, 0, "ZerroLine");
			}
			else if (State == State.Configure)
			{
				a1 = new double[Period];
				a2 = new double[Period];	
				Num = 0;
				Denom = 0.5 * Period * (Period - 1);
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < Period) return;
			Array.Clear(a1, 0, Period);
			Array.Clear(a1, 0, Period);
			
			for (int i = 1; i < Period; i++)
			{
				a1[i] = Input[i - 1];
				a2[i] = -i;
			}
			
			Num = 0;
			for (int i = 2; i < Period; i++)
			{
				for (int j = 1; j < i - 1; j++)
					Num = Num - Math.Sign(a1[i] - a1[j]);
			}
			
			Net_Ehlers[0] = Multi * Num / Denom;			
			
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(5, int.MaxValue)]
		[Display(Name="Period", Description="Period", Order=1, GroupName="Parameters")]
		public int Period
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Multi", Description="Multiplicator", Order=2, GroupName="Parameters")]
		public int Multi
		{ get; set; }

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> Net_Ehlers
		{
			get { return Values[0]; }
		}

		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology[] cacheEhlersNoiseEliminationTechnology;
		public AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(int period, int multi)
		{
			return EhlersNoiseEliminationTechnology(Input, period, multi);
		}

		public AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(ISeries<double> input, int period, int multi)
		{
			if (cacheEhlersNoiseEliminationTechnology != null)
				for (int idx = 0; idx < cacheEhlersNoiseEliminationTechnology.Length; idx++)
					if (cacheEhlersNoiseEliminationTechnology[idx] != null && cacheEhlersNoiseEliminationTechnology[idx].Period == period && cacheEhlersNoiseEliminationTechnology[idx].Multi == multi && cacheEhlersNoiseEliminationTechnology[idx].EqualsInput(input))
						return cacheEhlersNoiseEliminationTechnology[idx];
			return CacheIndicator<AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology>(new AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology(){ Period = period, Multi = multi }, input, ref cacheEhlersNoiseEliminationTechnology);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(int period, int multi)
		{
			return indicator.EhlersNoiseEliminationTechnology(Input, period, multi);
		}

		public Indicators.AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(ISeries<double> input , int period, int multi)
		{
			return indicator.EhlersNoiseEliminationTechnology(input, period, multi);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(int period, int multi)
		{
			return indicator.EhlersNoiseEliminationTechnology(Input, period, multi);
		}

		public Indicators.AUN_Indi.Ehlers.EhlersNoiseEliminationTechnology EhlersNoiseEliminationTechnology(ISeries<double> input , int period, int multi)
		{
			return indicator.EhlersNoiseEliminationTechnology(input, period, multi);
		}
	}
}

#endregion
