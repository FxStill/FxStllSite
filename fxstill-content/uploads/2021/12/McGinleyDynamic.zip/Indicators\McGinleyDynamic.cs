#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class McGinleyDynamic : Indicator
	{
		private double Num;
		
		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				
				Description									= @"McGinley Dynamic";
				Name										= "McGinley Dynamic";
				Calculate									= Calculate.OnBarClose;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				
				Period 										= 10;
				Smoothing                                   = 0.6;
				Exponent                                    = 4;
				BColor										= Brushes.DodgerBlue;
				SColor										= Brushes.Crimson;				
				
				AddPlot(Brushes.ForestGreen, "McGinleyDynamic");
			}
			else if (State == State.Configure)
			{
				Num = Smoothing * Period;
			}
		}

		protected override void OnBarUpdate()
		{
			if (CurrentBar < 0)
				return;
			
			if (CurrentBar == 0)
				Value[0] = Input[0];
			else
				Value[0] = Value[1] + (Input[0] - Value[1]) / (Num * Math.Pow(Input[0] / Value[1], Exponent));
			
		    if (Value[0] < Input[0]) PlotBrushes[0][0] = BColor;
    		else
      		   	if (Value[0] > Input[0]) 	   
			   		PlotBrushes[0][0] = SColor;					
		}
		
#region Properties		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Period", GroupName = "Parameters", Order = 0)]
		public int Period { get; set; }

		[NinjaScriptProperty]
		[Range(0.1, double.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name="Smoothing", GroupName="Parameters", Order = 1)]
		public double Smoothing
		{ get; set; }	
		
		[NinjaScriptProperty, Range(1, int.MaxValue)]
		[Display(ResourceType = typeof(Custom.Resource), Name = "Exponent", GroupName = "Parameters", Order = 2)]
		public int Exponent { get; set; }
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Long Color", Description="Buy Color", Order=3, GroupName="Parameters")]
		public Brush BColor
		{ get; set; }

		[Browsable(false)]
		public string BColorSerializable
		{
			get { return Serialize.BrushToString(BColor); }
			set { BColor = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Short Color", Description="Sell Color", Order=4, GroupName="Parameters")]
		public Brush SColor
		{ get; set; }

		[Browsable(false)]
		public string SColorSerializable
		{
			get { return Serialize.BrushToString(SColor); }
			set { SColor = Serialize.StringToBrush(value); }
		}	
		
		[Browsable(false)]
		public Series<double> McGinley
		{
			get { return Values[0]; }
		}
#endregion		
		
	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private McGinleyDynamic[] cacheMcGinleyDynamic;
		public McGinleyDynamic McGinleyDynamic(int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			return McGinleyDynamic(Input, period, smoothing, exponent, bColor, sColor);
		}

		public McGinleyDynamic McGinleyDynamic(ISeries<double> input, int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			if (cacheMcGinleyDynamic != null)
				for (int idx = 0; idx < cacheMcGinleyDynamic.Length; idx++)
					if (cacheMcGinleyDynamic[idx] != null && cacheMcGinleyDynamic[idx].Period == period && cacheMcGinleyDynamic[idx].Smoothing == smoothing && cacheMcGinleyDynamic[idx].Exponent == exponent && cacheMcGinleyDynamic[idx].BColor == bColor && cacheMcGinleyDynamic[idx].SColor == sColor && cacheMcGinleyDynamic[idx].EqualsInput(input))
						return cacheMcGinleyDynamic[idx];
			return CacheIndicator<McGinleyDynamic>(new McGinleyDynamic(){ Period = period, Smoothing = smoothing, Exponent = exponent, BColor = bColor, SColor = sColor }, input, ref cacheMcGinleyDynamic);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.McGinleyDynamic McGinleyDynamic(int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			return indicator.McGinleyDynamic(Input, period, smoothing, exponent, bColor, sColor);
		}

		public Indicators.McGinleyDynamic McGinleyDynamic(ISeries<double> input , int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			return indicator.McGinleyDynamic(input, period, smoothing, exponent, bColor, sColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.McGinleyDynamic McGinleyDynamic(int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			return indicator.McGinleyDynamic(Input, period, smoothing, exponent, bColor, sColor);
		}

		public Indicators.McGinleyDynamic McGinleyDynamic(ISeries<double> input , int period, double smoothing, int exponent, Brush bColor, Brush sColor)
		{
			return indicator.McGinleyDynamic(input, period, smoothing, exponent, bColor, sColor);
		}
	}
}

#endregion
