#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private FxStill.SmartMoney.MarketStructuresLite[] cacheMarketStructuresLite;

		
		public FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}


		
		public FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input, int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			if (cacheMarketStructuresLite != null)
				for (int idx = 0; idx < cacheMarketStructuresLite.Length; idx++)
					if (cacheMarketStructuresLite[idx].Period == period && cacheMarketStructuresLite[idx].bLbl == bLbl && cacheMarketStructuresLite[idx].iDist == iDist && cacheMarketStructuresLite[idx].iFontSz == iFontSz && cacheMarketStructuresLite[idx].BuyClr == buyClr && cacheMarketStructuresLite[idx].SellClr == sellClr && cacheMarketStructuresLite[idx].iWdth == iWdth && cacheMarketStructuresLite[idx].eStyle == eStyle && cacheMarketStructuresLite[idx].EqualsInput(input))
						return cacheMarketStructuresLite[idx];
			return CacheIndicator<FxStill.SmartMoney.MarketStructuresLite>(new FxStill.SmartMoney.MarketStructuresLite(){ Period = period, bLbl = bLbl, iDist = iDist, iFontSz = iFontSz, BuyClr = buyClr, SellClr = sellClr, iWdth = iWdth, eStyle = eStyle }, input, ref cacheMarketStructuresLite);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}


		
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input , int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(Input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}


		
		public Indicators.FxStill.SmartMoney.MarketStructuresLite MarketStructuresLite(ISeries<double> input , int period, bool bLbl, int iDist, int iFontSz, Brush buyClr, Brush sellClr, int iWdth, DashStyleHelper eStyle)
		{
			return indicator.MarketStructuresLite(input, period, bLbl, iDist, iFontSz, buyClr, sellClr, iWdth, eStyle);
		}

	}
}

#endregion
