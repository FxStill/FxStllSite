#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion
///+----------------------------------------------------------------------------------------------------------+
///|   Site:             https://fxstill.com                                                                  |
///|   Telegram:         https://t.me/AndreiFrX                                                               |
///|   Telegram Channel: https://t.me/fxstill (Literature on cryptocurrencies, development and code. )        |
///|                                   Don't forget to subscribe!                                             |
///|   ВКонтакте:        https://vk.com/AndreiFrX                                                             |
///|   Группа ВКонтакте: https://vk.com/fxstill                                                               |
///+----------------------------------------------------------------------------------------------------------+

/**************************************************************************************************************
This script uses the highs and lows of the candles (instead of the close) to make a "channel" to reference 
while scalping.
Use the green lower line as a guide to go long and the red upper line as a guide to go short. 
You may use the lines as potential entry points and direction but you may want to consider exiting before 
the opposite colored line prints, as that may be too late. As always, entries and exits are at the discretion 
of each trader.
You will need to adjust the "Line Spacing" settings as you change instruments, chart timeframes, and/or 
volatility increases/decreases. 
**************************************************************************************************************/

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class NSDT : Indicator
	{
		
		public static bool IsRising<T>(Series<T> series, int shift, int period) where T : IComparable<T> {
			for (int i = shift; i < period; i++) {
				if (series[shift].CompareTo(series[shift + 1]) <= 0 )
					return false;
			}
			return true;
		}
		public static bool IsRising(Series<double> series, int shift, int period) {
			for (int i = shift; i < period; i++) {
				if (series[shift] <= series[shift + 1])
					return false;
			}
			return true;
		}		
		
		public static bool IsFalling<T>(Series<T> series, int shift, int period) where T : IComparable<T> {
			for (int i = shift; i < period; i++) {
				if (series[shift].CompareTo(series[shift + 1]) >= 0 )
					return false;
			}
			return true;
		}
		public static bool IsFalling(Series<double> series, int shift, int period) {
			for (int i = shift; i < period; i++) {
				if (series[shift] >= series[shift + 1])
					return false;
			}
			return true;
		}
		
		private Series<double> ma1;
		private Series<double> ma2;
		private Series<int>    signal;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"NSDT Scalping Channel. Author: FxStill. Website: https://fxstill.com Channel: https://t.me/fxstill. Don't forget to subscribe!";
				Name										= "NSDT";
				Calculate									= Calculate.OnBarClose;
				MaximumBarsLookBack                         = MaximumBarsLookBack.Infinite;
				IsOverlay									= true;
				DisplayInDataBox							= true;
				DrawOnPricePanel							= true;
				DrawHorizontalGridLines						= true;
				DrawVerticalGridLines						= true;
				PaintPriceMarkers							= true;
				ScaleJustification							= NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive					= true;
				Length					    = 9;
				Period                      = 2;
				dUpper                      = 1.0005;
				dLow                        = 0.9995;
				bUseAlert                   = true;
				ClrRising					= Brushes.LimeGreen;
				ClrFalling					= Brushes.Crimson;
				ClrNeutral                  = (this.BackBrush == null)? Brushes.Gray: this.BackBrush;
				Opacity                     = 3;
				AddPlot(Brushes.Gray, "UpperLine");
				AddPlot(Brushes.Gray, "LowerLine");
			}
			else if (State == State.Configure)
			{
			}
			else if (State == State.DataLoaded)
			{				
				ma1    = new Series<double>(this);
				ma2    = new Series<double>(this);
				signal = new Series<int>(this);
				
			}
			else if (State == State.Realtime) {
			}
		}

		protected override void OnBarUpdate()
		{
			signal[0] = 0;
			if (CurrentBar <= Length) {
				ma1[0] = High[0];
				ma2[0] = Low[0];
				return;
			}
			ma1[0] = dUpper * WMA(High, Length)[0];
			ma2[0] = dLow *   WMA(Low,  Length)[0];
			
			if (IsRising(ma1, 0, Period) ){
				PlotBrushes[1][0] = ClrRising;
				signal[0] = 1; // enter long
				
			}
			if (IsFalling(ma2, 0, Period) ){
			    PlotBrushes[0][0] = ClrFalling;
				signal[0] = -1; //enter short
			}			
			
			UpperLine[0] = ma1[0];
			LowerLine[0] = ma2[0];

			Draw.Region(this, "RegUp", CurrentBar, 0,  Median , ma1, 
									Brushes.Transparent, ClrFalling, Opacity, Displacement);	
			Draw.Region(this, "RegDw", CurrentBar, 0,  Median , ma2, 
									Brushes.Transparent, ClrRising, Opacity, Displacement);		
			
			if (bUseAlert) {
				if (ma1[0] < High[0] ) {
					Alert("NSDTsignal1", Priority.Low, "Breakdown of the channel up", NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, ClrNeutral, ClrRising);
				}
				if (ma2[0] > Low[0] ) {
					Alert("NSDTsignal2", Priority.Low, "Breakdown of the channel down", NinjaTrader.Core.Globals.InstallDir + @"\sounds\Alert1.wav", 10, ClrNeutral, ClrFalling);				
				}
			}
			
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Length", Description="WMA length", Order=1, GroupName="Parameters")]
		public int Length
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(2, 100)]
		[Display(Name="Period", Description="Period length", Order=2, GroupName="Parameters")]
		public int Period
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Range(1.0005, double.MaxValue)]
		[Display(Name="Upper Space", Description="Upper Line Spacing", Order=3, GroupName="Parameters")]
		public double dUpper
		{ get; set; }
		
		[NinjaScriptProperty]
		[Range(0.9995, double.MaxValue)]
		[Display(Name="Low Space", Description="Low Line Spacing", Order=4, GroupName="Parameters")]
		public double dLow
		{ get; set; }		
		
		[NinjaScriptProperty]
		[Display(Name="Use Alert", Description="Use Alert", Order=5, GroupName="Parameters")]
		public bool bUseAlert
		{ get; set; }		

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ClrRising", Description="Color Rising", Order=6, GroupName="Parameters")]
		public Brush ClrRising
		{ get; set; }

		[Browsable(false)]
		public string ClrRisingSerializable
		{
			get { return Serialize.BrushToString(ClrRising); }
			set { ClrRising = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ClrFalling", Description="Color Falling", Order=7, GroupName="Parameters")]
		public Brush ClrFalling
		{ get; set; }

		[Browsable(false)]
		public string ClrFallingSerializable
		{
			get { return Serialize.BrushToString(ClrFalling); }
			set { ClrFalling = Serialize.StringToBrush(value); }
		}			
		
		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name="Opacity", Description="Opacity", Order=8, GroupName="Parameters")]
		public int Opacity
		{ get; set; }		
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="ClrNeutral", Description="Color Neutral", Order=9, GroupName="Parameters")]
		public Brush ClrNeutral
		{ get; set; }

		[Browsable(false)]
		public string ClrNeutralSerializable
		{
			get { return Serialize.BrushToString(ClrNeutral); }
			set { ClrNeutral = Serialize.StringToBrush(value); }
		}			
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpperLine
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> LowerLine
		{
			get { return Values[1]; }
		}
		
		[Browsable(false)]
		[XmlIgnore]
		public Series<int> TrendSignal
		{
			get {return signal;} 
		}		
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private NSDT[] cacheNSDT;
		public NSDT NSDT(int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			return NSDT(Input, length, period, dUpper, dLow, bUseAlert, clrRising, clrFalling, opacity, clrNeutral);
		}

		public NSDT NSDT(ISeries<double> input, int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			if (cacheNSDT != null)
				for (int idx = 0; idx < cacheNSDT.Length; idx++)
					if (cacheNSDT[idx] != null && cacheNSDT[idx].Length == length && cacheNSDT[idx].Period == period && cacheNSDT[idx].dUpper == dUpper && cacheNSDT[idx].dLow == dLow && cacheNSDT[idx].bUseAlert == bUseAlert && cacheNSDT[idx].ClrRising == clrRising && cacheNSDT[idx].ClrFalling == clrFalling && cacheNSDT[idx].Opacity == opacity && cacheNSDT[idx].ClrNeutral == clrNeutral && cacheNSDT[idx].EqualsInput(input))
						return cacheNSDT[idx];
			return CacheIndicator<NSDT>(new NSDT(){ Length = length, Period = period, dUpper = dUpper, dLow = dLow, bUseAlert = bUseAlert, ClrRising = clrRising, ClrFalling = clrFalling, Opacity = opacity, ClrNeutral = clrNeutral }, input, ref cacheNSDT);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.NSDT NSDT(int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			return indicator.NSDT(Input, length, period, dUpper, dLow, bUseAlert, clrRising, clrFalling, opacity, clrNeutral);
		}

		public Indicators.NSDT NSDT(ISeries<double> input , int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			return indicator.NSDT(input, length, period, dUpper, dLow, bUseAlert, clrRising, clrFalling, opacity, clrNeutral);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.NSDT NSDT(int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			return indicator.NSDT(Input, length, period, dUpper, dLow, bUseAlert, clrRising, clrFalling, opacity, clrNeutral);
		}

		public Indicators.NSDT NSDT(ISeries<double> input , int length, int period, double dUpper, double dLow, bool bUseAlert, Brush clrRising, Brush clrFalling, int opacity, Brush clrNeutral)
		{
			return indicator.NSDT(input, length, period, dUpper, dLow, bUseAlert, clrRising, clrFalling, opacity, clrNeutral);
		}
	}
}

#endregion
