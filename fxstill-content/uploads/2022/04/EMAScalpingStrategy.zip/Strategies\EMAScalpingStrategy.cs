#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.Indicators;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Strategies in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Strategies
{
	[Gui.CategoryOrder("Parameters", 1)] 
	[Gui.CategoryOrder("View", 2)] 	
	public class EMAScalpingStrategy : Strategy
	{
		public enum ENTRY_TYPE{
			SHORT_LONG,
			ONLY_LONG,
			ONLY_SHORT
		};
		private EMA EMA1;
		private EMA EMA2;
		private Series<bool> priceUnder, priceOver;
		private Series<double> priceShort, priceLong;
		private bool AllowLong() {return eType == ENTRY_TYPE.SHORT_LONG || eType == ENTRY_TYPE.ONLY_LONG;}
		private bool AllowShort() {return eType == ENTRY_TYPE.SHORT_LONG || eType == ENTRY_TYPE.ONLY_SHORT;}
		private int iStartTime, iEndTime;
//		private Brush brBack;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description									= @"Translate from Pine: Vendor FxStill. Website: https://fxstill.com Channel: https://t.me/fxstill. Don't forget to subscribe!";
				Name										= "EMAScalpingStrategy";
				Calculate									= Calculate.OnBarClose;
				EntriesPerDirection							= 1;
				EntryHandling								= EntryHandling.AllEntries;
				IsExitOnSessionCloseStrategy				= true;
				ExitOnSessionCloseSeconds					= 30;
				IsFillLimitOnTouch							= false;
				MaximumBarsLookBack							= MaximumBarsLookBack.TwoHundredFiftySix;
				OrderFillResolution							= OrderFillResolution.Standard;
				Slippage									= 0;
				StartBehavior								= StartBehavior.WaitUntilFlat;
				TimeInForce									= TimeInForce.Gtc;
				TraceOrders									= false;
				RealtimeErrorHandling						= RealtimeErrorHandling.StopCancelClose;
				StopTargetHandling							= StopTargetHandling.PerEntryExecution;
				BarsRequiredToTrade							= 20;
				// Disable this property for performance gains in Strategy Analyzer optimizations
				// See the Help Guide for additional information
				IsInstantiatedOnEachOptimizationIteration	= true;
				Avlength					= 9;
				LengthMA					= 21;
				StopPer					= 0.01;
				TakePer					= 0.03;
				eType                   = ENTRY_TYPE.SHORT_LONG;
				StartTime               = new DateTime();
				EndTime                 = new DateTime();
				bRev                    = false;
				
				ClrRising					= Brushes.LimeGreen;
				ClrFalling					= Brushes.Crimson;
				ClrNeutral                  = Brushes.Aqua;
//				Opacity                     = 3;		
				
				StartTime = EndTime = DateTime.Now;
//				StartTime.AddDays(-1);
//				EndTime.AddDays(10);				
				
//				AddPlot(Brushes.Green, "UpperLine");
//				AddPlot(Brushes.Red, "LowerLine");				
			}
			else if (State == State.Configure)
			{
				ClearOutputWindow();
				

//				StartTime = EndTime = DateTime.Now;
//				StartTime.AddDays(-1);
//				EndTime.AddDays(1);
				
				priceUnder = new Series<bool>(this);
				priceOver  = new Series<bool>(this);
				priceShort = new Series<double>(this);
				priceLong  = new Series<double>(this);
			}
			else if (State == State.DataLoaded)
			{				
				EMA1				= EMA(Close, Convert.ToInt32(Avlength));
				EMA2				= EMA(Close, Convert.ToInt32(LengthMA));
				
				EMA1.Plots[0].Brush = ClrRising;
				EMA2.Plots[0].Brush = ClrFalling;
				
				AddChartIndicator(EMA1);
				AddChartIndicator(EMA2);
				
				SetProfitTarget("", CalculationMode.Percent, TakePer);
				SetStopLoss("", CalculationMode.Percent, StopPer, false);
				
				iStartTime = ToTime(StartTime);
				iEndTime   = ToTime(EndTime);			
//				brBack = new SolidColorBrush(Color.);
//				brBack = Brushes.Transparent;//ClrNeutral;
//				brBack.Opacity = 0.3;//Opacity;
			}
		}

		protected override void OnBarUpdate()
		{
			if (BarsInProgress != 0) 
				return;

			if (CurrentBars[0] < 5) {
				priceShort[0] = priceLong[0] = Close[0];
				priceUnder[0] = priceOver[0] = false;
				return;
			}
			
			if (EMA1[0] < EMA2[0]) {priceUnder[0] = true; priceOver[0] = false;}
			else {priceOver[0] = true; priceUnder[0] = false;}
			
			if ( /*priceUnder[1] == false && priceUnder[0] == true*/CrossAbove(EMA2, EMA1, 1) ) {
				priceShort[0] = Close[0];
				priceLong[0] = priceLong[1];
			} else 
				if (/*priceOver[1] == false && priceOver[0] == true*/CrossBelow(EMA2, EMA1, 1) ) {
					priceLong[0] = Close[0];
					priceShort[0] = priceShort[1];
				} else {
					priceLong[0] = priceLong[1];
					priceShort[0] = priceShort[1];
				}
				
//			int iTime = ToTime(Time[0]);	
//Print("Prev: "+iStartTime+" Now: "+iTime+" Next: "+iEndTime);				
//			if ((iStartTime > iTime) || (iEndTime <= iTime) ) return;

			if(DateTime.Compare(StartTime, Time[0]) > 0 || DateTime.Compare(EndTime, Time[0]) <= 0) 
				return;
			
			BackBrushes[0] = ClrNeutral;
			
			double shortPositionChange = (((priceShort[0] - Close[0]) / priceShort[0]) * 100);
			double longPositionChange  = (((Close[0] - priceLong[0]) / priceLong[0]) * 100);							
				
			if (shortPositionChange >= TakePer && priceUnder[0] == true && 	AllowShort() ) {
				switch (Position.MarketPosition) {
					case MarketPosition.Flat:
						if (!bRev) EnterShort(Convert.ToInt32(DefaultQuantity), "");
						else EnterLong(Convert.ToInt32(DefaultQuantity), "");
//						EnterLong(Convert.ToInt32(DefaultQuantity));
						break;
					case MarketPosition.Long:
						if (!bRev) {
							ExitLong(Convert.ToInt32(DefaultQuantity), "", "");
							EnterShort(Convert.ToInt32(DefaultQuantity), "");
						} else {
							ExitShort(Convert.ToInt32(DefaultQuantity), "", "");
							EnterLong(Convert.ToInt32(DefaultQuantity));							
						}
						break;
					case MarketPosition.Short:
//						EnterLong(Convert.ToInt32(DefaultQuantity));
						break;
				}				
				
			}
			if (longPositionChange >= TakePer && priceOver[0] == true && AllowLong() ) {	
				switch (Position.MarketPosition) {
					case MarketPosition.Flat:
						if (!bRev) EnterLong(Convert.ToInt32(DefaultQuantity), "");
						else EnterShort(Convert.ToInt32(DefaultQuantity), "");
//						EnterLong(Convert.ToInt32(DefaultQuantity));
						break;
					case MarketPosition.Long:
						break;
					case MarketPosition.Short:
						if (!bRev) {
							ExitShort(Convert.ToInt32(DefaultQuantity), "", "");
							EnterLong(Convert.ToInt32(DefaultQuantity));
						} else {
							ExitLong(Convert.ToInt32(DefaultQuantity), "", "");
							EnterShort(Convert.ToInt32(DefaultQuantity), "");							
						}
//						EnterLong(Convert.ToInt32(DefaultQuantity));						break;
						
						break;
				}					
				
				
				
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Super Fast EMA", Description="Super Fast EMA", Order=1, GroupName="Parameters")]
		public int Avlength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name="Fast EMA", Description="Fast EMA", Order=2, GroupName="Parameters")]
		public int LengthMA
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Stop Loss, %", Description="Stop Loss, %", Order=3, GroupName="Parameters")]
		public double StopPer
		{ get; set; }

		[NinjaScriptProperty]
		[Range(0, double.MaxValue)]
		[Display(Name="Take Profit %", Description="Take Profit %", Order=4, GroupName="Parameters")]
		public double TakePer
		{ get; set; }
		
		[NinjaScriptProperty]
		[Display(Name="Entry Type", Description="Entry Type", Order=5, GroupName="Parameters")]
		public ENTRY_TYPE eType
		{ get; set; }		
		
		[NinjaScriptProperty]
//		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="StartingTime", Order=6, GroupName="Parameters")]
		public DateTime StartTime
		{ get; set; }

		[NinjaScriptProperty]
//		[PropertyEditor("NinjaTrader.Gui.Tools.TimeEditorKey")]
		[Display(Name="EndingTime", Order=7, GroupName="Parameters")]
		public DateTime EndTime
		{ get; set; }	
		
		[NinjaScriptProperty]
		[Display(Name="Reverse", Description="Reverse", Order=8, GroupName="Parameters")]
		public bool bRev
		{ get; set; }			
		
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Color Super Fast EMA", Description="Color Super Fast EMA", Order=1, GroupName="View")]
		public Brush ClrRising
		{ get; set; }

		[Browsable(false)]
		public string ClrRisingSerializable
		{
			get { return Serialize.BrushToString(ClrRising); }
			set { ClrRising = Serialize.StringToBrush(value); }
		}			

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Color Fast EMA", Description="Color Fast EMA", Order=2, GroupName="View")]
		public Brush ClrFalling
		{ get; set; }

		[Browsable(false)]
		public string ClrFallingSerializable
		{
			get { return Serialize.BrushToString(ClrFalling); }
			set { ClrFalling = Serialize.StringToBrush(value); }
		}			
		
		[NinjaScriptProperty]
		[Range(0, 100)]
		[Display(Name="Opacity", Description="Opacity", Order=3, GroupName="View")]
		public int Opacity
		{ get; set; }		
		
		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name="Color Time Zone", Description="Color Time Zone", Order=4, GroupName="View")]
		public Brush ClrNeutral
		{ get; set; }

		[Browsable(false)]
		public string ClrNeutralSerializable
		{
			get { return Serialize.BrushToString(ClrNeutral); }
			set { ClrNeutral = Serialize.StringToBrush(value); }
		}			
		
/*		
		[Browsable(false)]
		[XmlIgnore]
		public Series<double> UpperLine
		{
			get { return Values[0]; }
		}

		[Browsable(false)]
		[XmlIgnore]
		public Series<double> LowerLine
		{
			get { return Values[1]; }
		}
*/		
		#endregion

	}
}
