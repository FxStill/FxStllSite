//+------------------------------------------------------------------+
//|                                                 SaveTemplate.mq4 |
//|                        Copyright 2013, MetaQuotes Software Corp. |
//|                                              http://www.mql5.com |
//+------------------------------------------------------------------+
#property copyright "Copyright 2013, MetaQuotes Software Corp."
#property link      "http://www.mql5.com"
#property version   "1.00"
#property strict
//#property show_inputs

extern int Number=0;
//+------------------------------------------------------------------+
//| Script program start function                                    |
//+------------------------------------------------------------------+
void OnStart()
{
string tmpl_name = IntegerToString(Number) + Symbol() + ".tpl";
if (!ChartSaveTemplate(0,tmpl_name) ) Print("������ ��� ",Symbol()," �� ��������: ",GetLastError() );
else Print("������ ��� ",Symbol()," �������� ������� " );

}
//+------------------------------------------------------------------+
